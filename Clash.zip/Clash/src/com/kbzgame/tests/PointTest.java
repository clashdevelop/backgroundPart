package com.kbzgame.tests;

import com.kbzgame.utils.Point;

public class PointTest {
	public static void main(String[] args){ 
		Point p = new Point(1,2);
		System.out.println(p);
	}
}
