package com.kbzgame.service.event;

public abstract class Event {
	//public abstract void test();
	public abstract boolean happen();
	public abstract void action();
	public abstract boolean alive();
}
