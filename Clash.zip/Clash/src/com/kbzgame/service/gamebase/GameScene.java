package com.kbzgame.service.gamebase;

public abstract class GameScene {
	public abstract boolean alive();
}
