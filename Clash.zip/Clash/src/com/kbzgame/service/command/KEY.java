package com.kbzgame.service.command;

public enum KEY {
	SKILLONE,SKILLTWO,SKILLTHREE,ATACK
}
