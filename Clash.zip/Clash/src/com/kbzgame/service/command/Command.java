package com.kbzgame.service.command;

public abstract class Command{
	public abstract void execute();
}
